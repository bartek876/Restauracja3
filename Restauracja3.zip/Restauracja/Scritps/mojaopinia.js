document.getElementById("opinionForm").addEventListener("submit", function (event) {
    event.preventDefault();

    // Pobieranie wartości z formularza
    const opinionName = document.getElementById("opinionName").value;
    const opinionText = document.getElementById("opinionText").value;
    const opinionRating = document.getElementById("opinionRating").value;

    // Tworzenie opinii
    const newOpinion = `
        <div class="Opinia">
            <div class="Opinia__header">
                <span class="Opinia__author">${opinionName || 'Anonim'}</span>
                <span class="Opinia__rating">${'★'.repeat(opinionRating)}</span>
            </div>
            <p class="Opinia__text">${opinionText}</p>
        </div>
    `;

    // Dodanie opinii do listy
    document.getElementById("opinionList").innerHTML += newOpinion;


});

